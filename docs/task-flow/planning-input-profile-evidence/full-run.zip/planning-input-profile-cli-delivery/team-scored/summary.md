# Complementary-team optimization under explicit fixed intervals

Quality metric: 串行乘积质量指标 (not an actual task success probability).
Adding a factor in [0,1] cannot raise this index; later correction benefits are not modeled.
Status: selected; optimality: candidate_set_optimum
Scope: generated candidate set only; domain validity remains pending.
Selected: ['team-chain-049bf70a3cfe0a9a11deea7d58233d223d0550e52499b96e3b5e5f04c1809aba', 'team-chain-13a073b417b6a8a43e9ba30de01e580246b0c6f050d2955c0d39124291800632']
Network: {'id': 'joint-web-1', 'chains': ['team-chain-049bf70a3cfe0a9a11deea7d58233d223d0550e52499b96e3b5e5f04c1809aba', 'team-chain-13a073b417b6a8a43e9ba30de01e580246b0c6f050d2955c0d39124291800632'], 'score': 0.6, 'objective': 'mean_of_per_task_normalized_chain_scores', 'relations': [{'kind': 'parallel', 'chains': ['team-chain-049bf70a3cfe0a9a11deea7d58233d223d0550e52499b96e3b5e5f04c1809aba', 'team-chain-13a073b417b6a8a43e9ba30de01e580246b0c6f050d2955c0d39124291800632']}, {'kind': 'resource_sharing', 'chains': ['team-chain-049bf70a3cfe0a9a11deea7d58233d223d0550e52499b96e3b5e5f04c1809aba', 'team-chain-13a073b417b6a8a43e9ba30de01e580246b0c6f050d2955c0d39124291800632'], 'artifacts': ['R-Dispatch', 'R-Seal-A', 'R-Survey']}], 'makespan_s': 40, 'cost_per_execution': 25, 'cost_unit': 'demo-credit/use'}
Blocked: []
